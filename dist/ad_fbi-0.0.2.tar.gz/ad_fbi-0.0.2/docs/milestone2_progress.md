# Progress Update:

* What has each group member done since the submission of Milestone 1?

Queenie Luo: I have finished editing the introduction and background sections according to milestone2’s requirement, and I will be responsible for publishing the finalized package to the PyPI site. 

Guangya Wan: I have finished creating the dual number class and implemented a few other basic elementary functions including add/divide/r_add/pow/sin/cos since milestone1.

Di Zhen: I have finished creating the dual number class by adding a method to check edge cases.

Mengyao Zheng: I have writen ‘How to use’ and  ‘Software Organization’ sections for the Milestone 2. And I also worked with Wenxu on writing the ‘Implementation details’ section.

Wenxu Liu: I have updated  ‘How to use’ and  ‘Software Organization’ sections for Milestone 2. I have also been working with Mengyao on writing the ‘Future Features’ section. 

* What tasks has each group member been assigned to for Milestone 2?

Queenie Luo: For milestone2, I have been assigned to optimize the introduction and background sections, and publish the finalized package to the PyPI site. 

Guangya Wan: For milestone2 I have been assigned to finish adding other remaining elementary functions and write test code for those functions.

Di Zhen: For milestone2 I have been assigned to complete the adding setters and decorators and a documentation for dual number class. 

Mengyao Zheng: For milestone 2, I plan to write the get_jacobian() method and multiple corresponding unit tests for the methods. I also plan to complete the documentations and comment lines for the forward_mode() class.

Wenxu: For milestone 2, I will work on initializing a ForwardMode Object with a scalar function, evaluating the input function at evaluation point and using multiple pytest files to test the working code.
